var player;
var upPressed = false;
var downPressed = false;
var leftPressed = false;
var rightPressed = false;
var spacePressed = false;

function setPlayerDirection(dir) {
	//Display the walk animation for the correct direction, remove the other directions
	//to ensure the player does not have both "left" and "right" applied at the same time
	player.classList.remove('up');
	player.classList.remove('left');
	player.classList.remove('right');
	player.classList.remove('down');

	player.classList.add(dir);
}

function keyUp(event) {
	if (event.keyCode == 37) {
		leftPressed = false;
	}

	if (event.keyCode == 39) {
		rightPressed = false;
	}

	if (event.keyCode == 38) {
		upPressed = false;
	}

	if (event.keyCode == 40) {
		downPressed = false;
	}

	if (event.keyCode == 32) {
		spacePressed = false;
	}
}


function move() {
	var left = player.offsetLeft;
	var top = player.offsetTop;

	if (downPressed) {
		setPlayerDirection('down');
		top = top + 1;
	}

	if (upPressed) {
		setPlayerDirection('up');
		top = top - 1;
	}

	if (leftPressed) {
		setPlayerDirection('left');
		left = left - 1;
	}

	if (rightPressed) {
		setPlayerDirection('right');
		left = left + 1;
	}
	
	

	//Get the the element at the coordinates for where the play will move to
	//All 4 corners of the player are required to check there is no collision on any side
	var playerTopLeft = document.elementFromPoint(left, top);
	var playerTopRight = document.elementFromPoint(left+32, top);
	var playerBottomLeft = document.elementFromPoint(left, top+48);
	var playerBottomRight = document.elementFromPoint(left+32, top+48);


	//If the element that the player is about to walk over contains the class "blocking" then
	// the player is not moved.
	// The player will only be moved to coordinates `top` and `left` if the element in that position is not blocking
	if (!playerTopLeft.classList.contains('blocking') && !playerTopRight.classList.contains('blocking')
		&& !playerBottomLeft.classList.contains('blocking') && !playerBottomRight.classList.contains('blocking')) {
		player.style.left = left + 'px';
		player.style.top = top + 'px';
	}

	//If any of the keys are being pressed, display the walk animation
	if (leftPressed || rightPressed || upPressed || downPressed) {
		player.classList.add('walk');
		player.classList.remove('stand');
	}
	//Otherwise, no keys are being pressed, display stand
	else {
		player.classList.add('stand');
		player.classList.remove('walk');
	}

}

function keyDown(event) {
	if (event.keyCode == 37) {
		leftPressed = true;
	}

	if (event.keyCode == 39) {
		rightPressed = true;
	}

	if (event.keyCode == 38) {
		upPressed = true;
	}

	if (event.keyCode == 40) {
		downPressed = true;
	}
	
	if (event.keyCode == 32) {
		spacePressed = true;
	}
}

function reload() {
	document.addEventListener('keydown', fire);
}

function fire(event) {
	document.removeEventListener('keydown', fire);
	setTimeout(reload, 500);
	if (spacePressed) {
		playerLeftOffset = player.offsetLeft;
		playerTopOffset = player.offsetTop;
		var arrow = document.createElement('div');
		arrow.style.top = playerTopOffset + 15 + 'px';
		arrow.style.left = playerLeftOffset + 10 + 'px';
		
		if (player.classList.contains('left')) {
			arrow.className = 'arrow left';
		}
		if (player.classList.contains('right')) {
			arrow.className = 'arrow right';
		}
		if (player.classList.contains('up')) {
			arrow.className = 'arrow up';
		}
		if (player.classList.contains('down')) {
			arrow.className = 'arrow down';
		}
		//arrow.className = 'arrow';
		var body = document.getElementsByTagName('body')[0];

		body.appendChild(arrow);

		setInterval(function(){
			var arrowTopOffset = arrow.offsetTop;
			var arrowLeftOffset = arrow.offsetLeft;
			var arrowTopLeft = document.elementFromPoint(arrowLeftOffset, arrowTopOffset);
			var arrowTopRight = document.elementFromPoint(arrowLeftOffset+8, arrowTopOffset);
			var arrowBottomLeft = document.elementFromPoint(arrowLeftOffset, arrowTopOffset+8);
			var arrowBottomRight = document.elementFromPoint(arrowLeftOffset+8, arrowTopOffset+8);
			if (!arrowTopLeft.classList.contains('blocking') && !arrowTopRight.classList.contains('blocking')
		&& !arrowBottomLeft.classList.contains('blocking') && !arrowBottomRight.classList.contains('blocking')) {
			//console.log(arrowLeftOffset);	
			console.log(arrowTopOffset);
			if (arrow.classList.contains('up'))
				{
					arrowTopOffset = arrowTopOffset - 2;
				}
				else if (arrow.classList.contains('right'))
				{
					arrowLeftOffset = arrowLeftOffset + 2;
				}
				else if (arrow.classList.contains('down'))
				{
					arrowTopOffset = arrowTopOffset + 2;
				}
				else if (arrow.classList.contains('left'))
				{
					arrowLeftOffset = arrowLeftOffset - 2;
				}
				arrow.style.left = arrowLeftOffset + 'px';
				arrow.style.top = arrowTopOffset + 'px';
		}
		}, 100);
		}
}


function gameStart() {
	player = document.getElementById('player');
	setInterval(move, 10);
	//setInterval(fire, 50);
	document.addEventListener('keydown', keyDown);
	document.addEventListener('keydown', fire);
	document.addEventListener('keyup', keyUp);
}


document.addEventListener('DOMContentLoaded', gameStart);


